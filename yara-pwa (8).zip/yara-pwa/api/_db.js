// Simple in-memory DB (module scope).
// In production, replace with persistent storage (Redis/DB).
export const db = new Map(); // userId -> { devices: Map(deviceId -> {...}) }

export function ensureUser(userId){
  if (!db.has(userId)) db.set(userId, { devices: new Map() });
  return db.get(userId);
}