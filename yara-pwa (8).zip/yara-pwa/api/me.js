import { ensureUser } from "./_db.js";

export default async function handler(req, res) {
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" });

  const userId = req.headers["x-user-id"];
  if (!userId) return res.status(400).json({ error: "X-User-Id obrigatório" });

  const auth = req.headers["authorization"] || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Sem token" });

  const user = ensureUser(userId);
  const valid = [...user.devices.values()].some(d => d.sessionToken === token && d.enabled);
  if (!valid) return res.status(403).json({ error: "Token inválido" });

  return res.status(200).json({ userId, devices: [...user.devices.keys()] });
}