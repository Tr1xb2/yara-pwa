import { webcrypto, randomBytes } from "crypto";
import { ensureUser } from "./_db.js";

export default async function handler(req, res) {
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const userId = req.headers["x-user-id"];
  if (!userId) return res.status(400).json({ error: "X-User-Id obrigatório" });

  const { deviceId, signature } = req.body || {};
  if (!deviceId || !signature) return res.status(400).json({ error: "Parâmetros faltando" });

  const user = ensureUser(userId);
  const device = user.devices.get(deviceId);
  if (!device || !device.enabled) return res.status(403).json({ error: "Device não autorizado" });
  if (!device.challenge) return res.status(400).json({ error: "Sem challenge ativo" });

  try {
    const publicKey = await webcrypto.subtle.importKey(
      "jwk",
      device.publicKeyJwk,
      { name: "ECDSA", namedCurve: "P-256" },
      false,
      ["verify"]
    );

    const ok = await webcrypto.subtle.verify(
      { name: "ECDSA", hash: "SHA-256" },
      publicKey,
      Buffer.from(signature, "base64"),
      Buffer.from(device.challenge, "utf-8") // cliente assina o texto do challenge
    );

    device.challenge = undefined;
    if (!ok) return res.status(401).json({ error: "Assinatura inválida" });

    const token = randomBytes(24).toString("base64url");
    device.sessionToken = token; // TTL curto seria ideal
    return res.status(200).json({ token, deviceId });
  } catch (e) {
    return res.status(500).json({ error: "Falha na verificação", detail: String(e) });
  }
}