import { randomUUID } from "crypto";
import { ensureUser } from "./_db.js";

export default async function handler(req, res) {
  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const userId = req.headers["x-user-id"];
  if (!userId) return res.status(400).json({ error: "X-User-Id obrigatório" });

  const { publicKeyJwk, label } = req.body || {};
  if (!publicKeyJwk) return res.status(400).json({ error: "publicKeyJwk obrigatório" });

  const user = ensureUser(userId);

  // allowlist de 1 device
  if (user.devices.size >= 1) {
    return res.status(403).json({ error: "Já existe um dispositivo pareado. Despareie antes." });
  }

  const deviceId = randomUUID();
  user.devices.set(deviceId, { publicKeyJwk, label: label || "Chromebook", enabled: true });
  return res.status(200).json({ deviceId });
}