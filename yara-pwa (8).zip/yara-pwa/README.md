# Yara PWA (Chromebook-paired)

Esta é uma PWA mínima da **Yara** com **pareamento por dispositivo** usando WebCrypto no cliente e
**APIs serverless** (padrão Vercel) para validar o dispositivo.

## Estrutura
- `public/` — arquivos estáticos (PWA)
- `src/app.js` — lógica do cliente (pareamento, login, chamada protegida)
- `api/*.js` — APIs serverless (parear, desafio, verificação, desparear, rota protegida)
- `vercel.json` — configuração de CORS básico para as APIs
- `package.json` — metadados do projeto

> Aviso: as funções serverless usam um **banco em memória** (variável de módulo).
  Em hospedagem serverless, isso pode reiniciar. Em produção real, substitua por um Redis (ex.: Upstash)
  ou outro banco persistente.

## Deploy (atalho)
1. Crie um repositório no GitHub chamado `yara-pwa` e suba estes arquivos.
2. No Vercel (conta gratuita), clique em **Add New → Project** e importe o repo `yara-pwa`.
3. Sem build command. Output: `public`. As funções em `api/` serão detectadas automaticamente.
4. Depois do deploy, acesse a URL fornecida e clique **"Instalar"** para tornar PWA.
