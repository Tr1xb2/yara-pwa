const API = ""; // vazio = mesma origem (em produção via Vercel)
const out = document.getElementById("out");
const statusEl = document.getElementById("status");
const userIdInput = document.getElementById("userId");

let deviceId = localStorage.getItem("deviceId");
let token = localStorage.getItem("token");
let userId = localStorage.getItem("userId") || "";
let privateKey = null;
let publicKeyJwk = null;

// IndexedDB helpers
const DB_NAME = "yara-keys";
function withDb(fn){ return new Promise((resolve, reject) => {
  const req = indexedDB.open(DB_NAME, 1);
  req.onupgradeneeded = () => req.result.createObjectStore("kvs");
  req.onsuccess = () => fn(req.result).then(resolve, reject);
  req.onerror = () => reject(req.error);
});}
async function kvSet(k, v){
  return withDb(db => new Promise((res, rej)=>{
    const tx = db.transaction("kvs", "readwrite");
    tx.objectStore("kvs").put(v, k);
    tx.oncomplete = () => res();
    tx.onerror = () => rej(tx.error);
  }));
}
async function kvGet(k){
  return withDb(db => new Promise((res, rej)=>{
    const tx = db.transaction("kvs", "readonly");
    const rq = tx.objectStore("kvs").get(k);
    rq.onsuccess = () => res(rq.result);
    rq.onerror = () => rej(rq.error);
  }));
}

function log(txt){ out.textContent += txt + "\n"; }
function setStatus(){
  statusEl.innerHTML = `Status: <b>${deviceId ? "pareado" : "não pareado"}${token?" (logado)":" (não logado)"} </b>`;
}
function needUserId(){
  if (!userId) throw new Error("Defina seu ID (e-mail ou nome) antes.");
}

// Instalar PWA
let deferredPrompt;
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferredPrompt = e; });
document.getElementById("btnInstall").onclick = async () => {
  if (deferredPrompt) {
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
  } else {
    alert("Se o botão não aparecer, abra o menu do Chrome e clique 'Instalar Yara'.");
  }
};

// Chaves ECDSA P-256
async function ensureKeys(){
  let priv = await kvGet("privateKey");
  let pubJwk = await kvGet("publicKeyJwk");
  if (!priv || !pubJwk) {
    const keyPair = await crypto.subtle.generateKey(
      { name: "ECDSA", namedCurve: "P-256" },
      false,
      ["sign", "verify"]
    );
    const jwk = await crypto.subtle.exportKey("jwk", keyPair.publicKey);
    await kvSet("privateKey", keyPair.privateKey);
    await kvSet("publicKeyJwk", jwk);
    privateKey = keyPair.privateKey;
    publicKeyJwk = jwk;
    return;
  }
  privateKey = priv;
  publicKeyJwk = pubJwk;
}

// Parear
async function pairDevice(){
  needUserId();
  await ensureKeys();
  const resp = await fetch(`/api/pair`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-User-Id": userId },
    body: JSON.stringify({ publicKeyJwk, label: "Chromebook do Leandro" })
  });
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.error || "Falha ao parear");
  deviceId = data.deviceId;
  localStorage.setItem("deviceId", deviceId);
  log("Pareado com deviceId: " + deviceId);
  setStatus();
}

// Login (challenge → assinatura)
async function signinWithProof(){
  needUserId();
  if (!deviceId) throw new Error("Dispositivo não pareado");
  await ensureKeys();

  const chResp = await fetch(`/api/auth-challenge`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-User-Id": userId },
    body: JSON.stringify({ deviceId })
  });
  const { challenge, error } = await chResp.json();
  if (!chResp.ok) throw new Error(error || "Falha ao obter challenge");

  const signatureBuf = await crypto.subtle.sign(
    { name: "ECDSA", hash: "SHA-256" },
    privateKey,
    new TextEncoder().encode(challenge)
  );
  const signatureB64 = btoa(String.fromCharCode(...new Uint8Array(signatureBuf)));

  const vResp = await fetch(`/api/auth-verify`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-User-Id": userId },
    body: JSON.stringify({ deviceId, signature: signatureB64 })
  });
  const vData = await vResp.json();
  if (!vResp.ok) throw new Error(vData.error || "Falha na verificação");

  token = vData.token;
  localStorage.setItem("token", token);
  log("Login ok. Token curto recebido.");
  setStatus();
}

// Desparear
async function unpair(){
  needUserId();
  if (!deviceId) return;
  await fetch(`/api/unpair`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-User-Id": userId },
    body: JSON.stringify({ deviceId })
  });
  localStorage.removeItem("deviceId");
  localStorage.removeItem("token");
  deviceId = null; token = null;
  log("Dispositivo despareado.");
  setStatus();
}

// Rota protegida
async function callMe(){
  needUserId();
  if (!token) throw new Error("Faça login primeiro");
  const resp = await fetch(`/api/me`, {
    headers: { "Authorization": `Bearer ${token}`, "X-User-Id": userId }
  });
  const txt = await resp.text();
  log("/api/me → " + txt);
}

// UI
document.getElementById("btnPair").onclick = () => pairDevice().catch(e=>log(e.message));
document.getElementById("btnLogin").onclick = () => signinWithProof().catch(e=>log(e.message));
document.getElementById("btnUnpair").onclick = () => unpair().catch(e=>log(e.message));
document.getElementById("btnMe").onclick = () => callMe().catch(e=>log(e.message));
document.getElementById("saveUser").onclick = () => {
  userId = userIdInput.value.trim();
  localStorage.setItem("userId", userId);
  log("ID definido: " + userId);
};

// Inicializa campo userId
userIdInput.value = userId;
setStatus();