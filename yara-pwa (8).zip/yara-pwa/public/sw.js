self.addEventListener("install", (e) => {
  e.waitUntil((async () => {
    const cache = await caches.open("yara-v1");
    await cache.addAll(["/", "/index.html", "/manifest.webmanifest", "/app.js"]);
  })());
});

self.addEventListener("fetch", (e) => {
  e.respondWith((async () => {
    const cached = await caches.match(e.request);
    return cached || fetch(e.request);
  })());
});